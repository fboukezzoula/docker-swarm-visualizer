package azure

import (
	"context"
	"fmt"
	"os"
	"os/exec"
	"strings"
	"time"
)

type CommandOptions struct {
	Command      string
	File         string
	NoWait       bool
	Output       string
	Subscription string
	Debug        bool
	OnlyErrors   bool
	Query        string
	CommandID    string // Pour az aks command result
}

type CommandRunner struct {
	config *Config
}

func NewCommandRunner(config *Config) *CommandRunner {
	return &CommandRunner{config: config}
}

func (c *CommandRunner) RunRemoteCommand(ctx context.Context, args []string, options *CommandOptions, verbose bool) error {
	if len(args) == 0 && options.Command == "" {
		return fmt.Errorf("no command provided")
	}

	ctx, cancel := context.WithTimeout(ctx, 5*time.Minute)
	defer cancel()

	var command string
	if options.Command != "" {
		command = options.Command
	} else {
		command = strings.Join(args, " ")
	}

	baseArgs := c.buildCommandArgs(command, options)

	if verbose {
		fmt.Println("➡️ Running command inside AKS cluster:")
		fmt.Printf("az %s\n", strings.Join(baseArgs, " "))
	}

	cmd := exec.CommandContext(ctx, "az", baseArgs...)
	cmd.Stdout = os.Stdout
	cmd.Stderr = os.Stderr
	cmd.Stdin = os.Stdin

	if err := cmd.Run(); err != nil {
		return fmt.Errorf("command execution failed: %w", err)
	}

	return nil
}

func (c *CommandRunner) buildCommandArgs(command string, options *CommandOptions) []string {
	baseArgs := []string{
		"aks", "command", "invoke",
		"--resource-group", c.config.ResourceName,
		"--name", c.config.AKSName,
	}

	// Command obligatoire
	if command != "" {
		baseArgs = append(baseArgs, "--command", command)
	}

	// Options conditionnelles
	if options.File != "" {
		baseArgs = append(baseArgs, "--file", options.File)
	} else if c.needsFileUpload(command) {
		baseArgs = append(baseArgs, "--file", ".")
	}

	if options.NoWait {
		baseArgs = append(baseArgs, "--no-wait")
	}

	if options.Output != "" {
		baseArgs = append(baseArgs, "--output", options.Output)
	}

	if options.Subscription != "" {
		baseArgs = append(baseArgs, "--subscription", options.Subscription)
	}

	if options.Debug {
		baseArgs = append(baseArgs, "--debug")
	}

	if options.OnlyErrors {
		baseArgs = append(baseArgs, "--only-show-errors")
	}

	if options.Query != "" {
		baseArgs = append(baseArgs, "--query", options.Query)
	}

	return baseArgs
}

func (c *CommandRunner) GetCommandResult(ctx context.Context, commandID string, options *CommandOptions, verbose bool) error {
	ctx, cancel := context.WithTimeout(ctx, 30*time.Second)
	defer cancel()

	baseArgs := []string{
		"aks", "command", "result",
		"--resource-group", c.config.ResourceName,
		"--name", c.config.AKSName,
	}

	if commandID != "" {
		baseArgs = append(baseArgs, "--command-id", commandID)
	}

	if options.Output != "" {
		baseArgs = append(baseArgs, "--output", options.Output)
	}

	if options.Subscription != "" {
		baseArgs = append(baseArgs, "--subscription", options.Subscription)
	}

	if options.Debug {
		baseArgs = append(baseArgs, "--debug")
	}

	if options.OnlyErrors {
		baseArgs = append(baseArgs, "--only-show-errors")
	}

	if options.Query != "" {
		baseArgs = append(baseArgs, "--query", options.Query)
	}

	if verbose {
		fmt.Println("➡️ Fetching command result:")
		fmt.Printf("az %s\n", strings.Join(baseArgs, " "))
	}

	cmd := exec.CommandContext(ctx, "az", baseArgs...)
	cmd.Stdout = os.Stdout
	cmd.Stderr = os.Stderr

	if err := cmd.Run(); err != nil {
		return fmt.Errorf("failed to get command result: %w", err)
	}

	return nil
}

func (c *CommandRunner) needsFileUpload(command string) bool {
	fileCommands := []string{
		"kubectl apply -f",
		"kubectl create -f",
		"kubectl replace -f",
		"kubectl delete -f",
		"helm install",
		"helm upgrade",
		"helm template",
	}

	for _, fileCmd := range fileCommands {
		if strings.Contains(command, fileCmd) {
			return true
		}
	}
	return false
}
