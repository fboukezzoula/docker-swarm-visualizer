package cmd

import (
    "fmt"
    "os"
    "xks/azure"

    "github.com/spf13/cobra"
)

var verbose bool

var rootCmd = &cobra.Command{
    Use:   "xks",
    Short: "XKS wraps az aks command invoke for kubectl and helm",
    Long:  `XKS is a CLI for running kubectl or helm commands securely inside a private AKS cluster.`,
    Run: func(cmd *cobra.Command, args []string) {
        if len(args) == 0 {
            fmt.Println("Usage: xks <kubectl|helm> ...")
            os.Exit(1)
        }

        azure.CheckEnvVars()

        if !azure.IsLoggedIn() {
            if err := azure.Login(); err != nil {
                fmt.Println("Login failed:", err)
                os.Exit(1)
            }

            if err := azure.SetSubscription(); err != nil {
                fmt.Println("Setting subscription failed:", err)
                os.Exit(1)
            }
        } else if verbose {
            fmt.Println("✅ Already authenticated.")
        }

        azure.RunRemoteCommand(args, verbose)
    },
}

func Execute() {
    rootCmd.PersistentFlags().BoolVarP(&verbose, "verbose", "v", false, "Enable verbose output")
    if err := rootCmd.Execute(); err != nil {
        fmt.Println(err)
        os.Exit(1)
    }
}
