# XKS - Execute Remote Kubectl/Helm via Azure AKS

`xks` is a Go CLI tool that wraps Azure AKS commands (`az aks command invoke`) to run `kubectl` or `helm` commands inside a private AKS cluster.

## ✅ Features

- Authenticates with a service principal if needed
- Verifies context via `az aks show`
- Supports `kubectl`, `helm`, and chained commands (`&&`)
- Automatically adds `--file .` for `kubectl apply -f`
- Verbose mode for debugging

## 🔧 Environment Variables

| Name               | Description                           |
|--------------------|---------------------------------------|
| AZURE_TENANTID     | Azure tenant ID                       |
| AZURE_APPID        | SPN App ID                            |
| AZURE_SECRETID     | SPN Secret                            |
| AZURE_SUBSCRIPTION | Azure subscription ID or name         |
| AKS_RESOURCE_NAME  | Resource group of the AKS cluster     |
| AKS_NAME           | Name of the AKS cluster               |

## 🚀 Usage

```bash
./xks kubectl get pods -n kube-system
./xks helm repo add bitnami https://charts.bitnami.com/bitnami && helm repo update && helm install nginx bitnami/nginx
./xks kubectl apply -f deployment.yaml  # will auto-attach --file .
```

Use verbose output:

```bash
./xks -v kubectl get nodes
```

## 🔨 Build

```bash
make build
```
