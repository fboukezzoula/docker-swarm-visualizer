package azure

import (
    "fmt"
    "os"
    "os/exec"
)

func getEnv(key string) string {
    val := os.Getenv(key)
    if val == "" {
        fmt.Printf("❌ Missing required environment variable: %s\n", key)
        os.Exit(1)
    }
    return val
}

func CheckEnvVars() {
    required := []string{
        "AZURE_TENANTID", "AZURE_APPID", "AZURE_SECRETID",
        "AZURE_SUBSCRIPTION", "AKS_RESOURCE_NAME", "AKS_NAME",
    }
    for _, key := range required {
        _ = getEnv(key)
    }
}

func IsLoggedIn() bool {
    cmd := exec.Command("az", "aks", "show",
        "--name", getEnv("AKS_NAME"),
        "--resource-group", getEnv("AKS_RESOURCE_NAME"),
    )
    cmd.Stdout = nil
    cmd.Stderr = nil
    return cmd.Run() == nil
}

func Login() error {
    fmt.Println("🔐 Logging in with service principal...")
    cmd := exec.Command("az", "login",
        "--service-principal",
        "--username", getEnv("AZURE_APPID"),
        "--password", getEnv("AZURE_SECRETID"),
        "--tenant", getEnv("AZURE_TENANTID"),
    )
    cmd.Stdout = os.Stdout
    cmd.Stderr = os.Stderr
    err := cmd.Run()
    if err != nil {
        return fmt.Errorf("failed to login: %w", err)
    }
    return nil
}

func SetSubscription() error {
    fmt.Println("🔧 Setting subscription...")
    cmd := exec.Command("az", "account", "set",
        "--subscription", getEnv("AZURE_SUBSCRIPTION"),
    )
    cmd.Stdout = os.Stdout
    cmd.Stderr = os.Stderr
    if err := cmd.Run(); err != nil {
        return fmt.Errorf("failed to set subscription: %w", err)
    }

    fmt.Println("📥 Fetching AKS credentials...")
    credCmd := exec.Command("az", "aks", "get-credentials",
        "--resource-group", getEnv("AKS_RESOURCE_NAME"),
        "--name", getEnv("AKS_NAME"),
    )
    credCmd.Stdout = os.Stdout
    credCmd.Stderr = os.Stderr
    if err := credCmd.Run(); err != nil {
        return fmt.Errorf("failed to fetch AKS credentials: %w", err)
    }

    return nil
}
