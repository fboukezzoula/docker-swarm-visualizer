package azure

import (
    "fmt"
    "os"
    "os/exec"
    "strings"
)

func RunRemoteCommand(args []string, verbose bool) {
    command := strings.Join(args, " ")

    baseArgs := []string{
        "aks", "command", "invoke",
        "--resource-group", getEnv("AKS_RESOURCE_NAME"),
        "--name", getEnv("AKS_NAME"),
        "--command", command,
    }

    if strings.Contains(command, "kubectl apply -f") {
        baseArgs = append(baseArgs, "--file", ".")
    }

    if verbose {
        fmt.Println("➡️ Running command inside AKS cluster:")
        fmt.Println("az", strings.Join(baseArgs, " "))
    }

    cmd := exec.Command("az", baseArgs...)
    cmd.Stdout = os.Stdout
    cmd.Stderr = os.Stderr
    cmd.Stdin = os.Stdin
    err := cmd.Run()
    if err != nil {
        fmt.Printf("❌ Failed to execute command: %v\n", err)
    }
}
