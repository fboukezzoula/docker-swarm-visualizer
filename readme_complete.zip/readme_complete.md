# XKS - AKS Command Proxy

[![Go Version](https://img.shields.io/github/go-mod/go-version/your-org/xks)](https://golang.org/)
[![License](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)
[![Release](https://img.shields.io/github/v/release/your-org/xks)](https://github.com/your-org/xks/releases)

XKS est un wrapper CLI pour `az aks command invoke` qui simplifie l'accès aux clusters AKS privés. Il permet d'exécuter des commandes `kubectl` et `helm` sans configuration VPN ou ExpressRoute.

## 🚀 Fonctionnalités

- **Accès simplifié** aux clusters AKS privés
- **Support complet** de toutes les options `az aks command invoke`
- **Authentification automatique** avec service principal
- **Gestion intelligente** des fichiers et dossiers
- **Mode asynchrone** avec récupération de résultats
- **Cross-platform** (Linux, Windows, macOS, ARM)

## 📋 Prérequis

- **Azure CLI** version 2.24.0 ou plus récente
- **Go** 1.19+ (pour le build depuis les sources)
- **Permissions Azure** :
  - `Microsoft.ContainerService/managedClusters/runcommand/action`
  - `Microsoft.ContainerService/managedclusters/commandResults/read`

## 🔧 Installation

### Option 1: Binaires pré-compilés

```bash
# Télécharger depuis les releases GitHub
curl -L https://github.com/your-org/xks/releases/latest/download/xks-linux -o xks
chmod +x xks
sudo mv xks /usr/local/bin/
```

### Option 2: Compilation depuis les sources

```bash
git clone https://github.com/your-org/xks.git
cd xks
make install
```

### Option 3: Via Go install

```bash
go install github.com/your-org/xks@latest
```

## ⚙️ Configuration

### 1. Créer le fichier de configuration

```bash
cp .env.example .env
```

### 2. Configurer les variables d'environnement

```bash
# Azure Service Principal
AZURE_TENANTID=your-tenant-id
AZURE_APPID=your-app-id
AZURE_SECRETID=your-secret
AZURE_SUBSCRIPTION=your-subscription-id-or-name

# AKS Cluster Info
AKS_RESOURCE_NAME=your-resource-group
AKS_NAME=your-aks-cluster
```

### 3. Créer un Service Principal (si nécessaire)

```bash
az ad sp create-for-rbac --name "xks-sp" --role "Azure Kubernetes Service Cluster User Role"
```

## 🎯 Utilisation

### Commandes de base

```bash
# Lister les pods
xks kubectl get pods -A

# Déployer une application
xks kubectl apply -f deployment.yaml

# Installer un chart Helm
xks helm install nginx bitnami/nginx
```

### Options avancées

```bash
# Commande directe avec output JSON
xks --command "kubectl get nodes" --output json

# Avec requête JMESPath
xks --command "kubectl get pods -A" --query "items[?status.phase=='Running'].metadata.name"

# Attachement de fichiers/dossiers
xks kubectl apply -f . --file ./manifests/

# Mode asynchrone
xks helm install app ./chart --no-wait

# Récupération de résultat asynchrone
xks --get-result --command-id "abc123"
```

### Commandes complexes

```bash
# Commandes multiples
xks --command "helm repo add bitnami https://charts.bitnami.com/bitnami && helm repo update && helm install nginx bitnami/nginx"

# Debug avec verbose
xks kubectl describe pod failing-pod --debug --verbose

# Format de sortie spécifique
xks kubectl get svc --output table --only-show-errors
```

## 🔨 Développement

### Structure du projet

```
xks/
├── main.go              # Point d'entrée
├── cmd/
│   └── root.go         # Commandes CLI
├── azure/
│   ├── config.go       # Configuration
│   ├── auth.go         # Authentification
│   └── command.go      # Exécution commandes
├── Makefile            # Automatisation build
├── .env.example        # Exemple configuration
└── README.md           # Documentation
```

### Commandes de développement

```bash
# Installer les dépendances
make deps

# Lancer les tests
make test

# Linter le code
make lint

# Construire localement
make build-local

# Mode développement
make dev ARGS="kubectl get pods"

# Scan de sécurité
make security
```

### Build pour toutes les plateformes

```bash
# Build complet
make build-all

# Créer une release
make release

# Nettoyage
make clean
```

## 📝 Options disponibles

### Flags principaux

| Flag | Description | Exemple |
|------|-------------|---------|
| `--command` | Commande directe | `--command "kubectl get pods"` |
| `--file` | Fichiers à attacher | `--file ./manifests/` |
| `--no-wait` | Mode asynchrone | `--no-wait` |
| `--verbose, -v` | Mode verbeux | `-v` |

### Flags de sortie Azure CLI

| Flag | Description | Valeurs |
|------|-------------|---------|
| `--output, -o` | Format de sortie | `json`, `table`, `yaml`, `tsv` |
| `--query` | Requête JMESPath | `"items[0].metadata.name"` |
| `--subscription` | Souscription | `"my-subscription"` |
| `--debug` | Logs complets | `--debug` |
| `--only-show-errors` | Erreurs uniquement | `--only-show-errors` |

### Flags pour résultats asynchrones

| Flag | Description | Exemple |
|------|-------------|---------|
| `--get-result` | Récupérer résultat | `--get-result` |
| `--command-id` | ID de commande | `--command-id "abc123"` |

## 🛠️ Build et Release

### Targets Makefile disponibles

```bash
make help                 # Afficher l'aide
make deps                 # Installer dépendances
make test                 # Lancer tests
make lint                 # Linter le code
make build-local          # Build OS courant
make build-linux          # Build Linux x86_64
make build-windows        # Build Windows x86_64
make build-darwin         # Build macOS x86_64
make build-arm            # Build ARM64
make build-all            # Build toutes plateformes
make install              # Installer localement
make release              # Créer release complète
make clean                # Nettoyer
make dev                  # Mode développement
make security             # Scan sécurité
```

### Exemple de workflow CI/CD

```yaml
name: Build and Release
on:
  push:
    tags: ['v*']
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-go@v4
        with:
          go-version: '1.21'
      - run: make test
      - run: make security
      - run: make release
      - uses: actions/upload-artifact@v3
        with:
          name: binaries
          path: dist/*.tar.gz
```

## 🔒 Sécurité

### Bonnes pratiques

1. **Variables d'environnement** : Utilisez un gestionnaire de secrets
2. **Service Principal** : Privilège minimum requis
3. **Rotation** : Renouvelez régulièrement les secrets
4. **Audit** : Surveillez les accès via Azure Monitor

### Scan de sécurité

```bash
# Installer gosec
go install github.com/securecodewarrior/gosec/v2/cmd/gosec@latest

# Lancer le scan
make security
```

## 🐛 Dépannage

### Erreurs communes

**❌ Authentication failed**
```bash
# Vérifier les variables d'environnement
xks --debug kubectl get pods
```

**❌ Missing required environment variable**
```bash
# Copier et remplir le .env
cp .env.example .env
```

**❌ Command execution failed**
```bash
# Mode verbeux pour plus de détails
xks -v kubectl get pods
```

### Logs et debugging

```bash
# Mode debug complet
xks --debug --verbose kubectl get nodes

# Vérifier la configuration
az account show
az aks show --name $AKS_NAME --resource-group $AKS_RESOURCE_NAME
```

## 📚 Exemples d'usage

### Cas d'usage DevOps

```bash
# Déploiement automatisé
xks kubectl apply -f k8s/ --file ./k8s/

# Monitoring
xks --command "kubectl top nodes" --output json

# Scaling
xks kubectl scale deployment app --replicas=5
```

### Cas d'usage développeur

```bash
# Debug application
xks kubectl logs -f deployment/app

# Port forwarding (limitation: pas de port forwarding direct)
xks kubectl get svc app -o jsonpath='{.status.loadBalancer.ingress[0].ip}'

# Exec dans un pod
xks kubectl exec -it app-pod -- /bin/bash
```

## 🤝 Contribution

1. **Fork** le projet
2. **Créer** une branche feature (`git checkout -b feature/amazing-feature`)
3. **Commit** vos changements (`git commit -m 'Add amazing feature'`)
4. **Push** vers la branche (`git push origin feature/amazing-feature`)
5. **Ouvrir** une Pull Request

## 📄 Licence

Distribué sous licence MIT. Voir `LICENSE` pour plus d'informations.

## 🆘 Support

- **Issues** : [GitHub Issues](https://github.com/your-org/xks/issues)
- **Discussions** : [GitHub Discussions](https://github.com/your-org/xks/discussions)
- **Documentation** : [Wiki](https://github.com/your-org/xks/wiki)

---

**⭐ Si ce projet vous aide, n'hésitez pas à lui donner une étoile !**