// main.go
package main

import (
    "log"
    "xks/cmd"

    "github.com/joho/godotenv"
)

func main() {
    if err := godotenv.Load(); err != nil {
        log.Println("⚠️  No .env file found, proceeding with existing environment variables.")
    }
    cmd.Execute()
}

// azure/config.go
package azure

import (
    "fmt"
    "os"
)

type Config struct {
    TenantID     string
    AppID        string
    SecretID     string
    Subscription string
    ResourceName string
    AKSName      string
}

func NewConfig() (*Config, error) {
    required := map[string]string{
        "AZURE_TENANTID":     "",
        "AZURE_APPID":        "",
        "AZURE_SECRETID":     "",
        "AZURE_SUBSCRIPTION": "",
        "AKS_RESOURCE_NAME":  "",
        "AKS_NAME":           "",
    }

    for key := range required {
        val := os.Getenv(key)
        if val == "" {
            return nil, fmt.Errorf("missing required environment variable: %s", key)
        }
        required[key] = val
    }

    return &Config{
        TenantID:     required["AZURE_TENANTID"],
        AppID:        required["AZURE_APPID"],
        SecretID:     required["AZURE_SECRETID"],
        Subscription: required["AZURE_SUBSCRIPTION"],
        ResourceName: required["AKS_RESOURCE_NAME"],
        AKSName:      required["AKS_NAME"],
    }, nil
}

// azure/auth.go
package azure

import (
    "context"
    "fmt"
    "os/exec"
    "time"
)

type AuthClient struct {
    config *Config
}

func NewAuthClient(config *Config) *AuthClient {
    return &AuthClient{config: config}
}

func (a *AuthClient) IsLoggedIn(ctx context.Context) bool {
    ctx, cancel := context.WithTimeout(ctx, 10*time.Second)
    defer cancel()

    cmd := exec.CommandContext(ctx, "az", "aks", "show",
        "--name", a.config.AKSName,
        "--resource-group", a.config.ResourceName,
        "--output", "none",
    )
    return cmd.Run() == nil
}

func (a *AuthClient) Login(ctx context.Context) error {
    ctx, cancel := context.WithTimeout(ctx, 30*time.Second)
    defer cancel()

    fmt.Println("🔐 Logging in with service principal...")
    cmd := exec.CommandContext(ctx, "az", "login",
        "--service-principal",
        "--username", a.config.AppID,
        "--password", a.config.SecretID,
        "--tenant", a.config.TenantID,
        "--output", "none",
    )
    
    if err := cmd.Run(); err != nil {
        return fmt.Errorf("failed to login: %w", err)
    }
    return nil
}

func (a *AuthClient) SetupCluster(ctx context.Context) error {
    ctx, cancel := context.WithTimeout(ctx, 30*time.Second)
    defer cancel()

    fmt.Println("🔧 Setting subscription...")
    cmd := exec.CommandContext(ctx, "az", "account", "set",
        "--subscription", a.config.Subscription,
    )
    if err := cmd.Run(); err != nil {
        return fmt.Errorf("failed to set subscription: %w", err)
    }

    fmt.Println("📥 Fetching AKS credentials...")
    credCmd := exec.CommandContext(ctx, "az", "aks", "get-credentials",
        "--resource-group", a.config.ResourceName,
        "--name", a.config.AKSName,
        "--overwrite-existing",
    )
    if err := credCmd.Run(); err != nil {
        return fmt.Errorf("failed to fetch AKS credentials: %w", err)
    }

    return nil
}

// azure/command.go
package azure

import (
    "context"
    "fmt"
    "os"
    "os/exec"
    "strings"
    "time"
)

type CommandOptions struct {
    Command      string
    File         string
    NoWait       bool
    Output       string
    Subscription string
    Debug        bool
    OnlyErrors   bool
    Query        string
    CommandID    string // Pour az aks command result
}

type CommandRunner struct {
    config *Config
}

func NewCommandRunner(config *Config) *CommandRunner {
    return &CommandRunner{config: config}
}

func (c *CommandRunner) RunRemoteCommand(ctx context.Context, args []string, options *CommandOptions, verbose bool) error {
    if len(args) == 0 && options.Command == "" {
        return fmt.Errorf("no command provided")
    }

    ctx, cancel := context.WithTimeout(ctx, 5*time.Minute)
    defer cancel()

    var command string
    if options.Command != "" {
        command = options.Command
    } else {
        command = strings.Join(args, " ")
    }

    baseArgs := c.buildCommandArgs(command, options)

    if verbose {
        fmt.Println("➡️ Running command inside AKS cluster:")
        fmt.Printf("az %s\n", strings.Join(baseArgs, " "))
    }

    cmd := exec.CommandContext(ctx, "az", baseArgs...)
    cmd.Stdout = os.Stdout
    cmd.Stderr = os.Stderr
    cmd.Stdin = os.Stdin
    
    if err := cmd.Run(); err != nil {
        return fmt.Errorf("command execution failed: %w", err)
    }
    
    return nil
}

func (c *CommandRunner) buildCommandArgs(command string, options *CommandOptions) []string {
    baseArgs := []string{
        "aks", "command", "invoke",
        "--resource-group", c.config.ResourceName,
        "--name", c.config.AKSName,
    }

    // Command obligatoire
    if command != "" {
        baseArgs = append(baseArgs, "--command", command)
    }

    // Options conditionnelles
    if options.File != "" {
        baseArgs = append(baseArgs, "--file", options.File)
    } else if c.needsFileUpload(command) {
        baseArgs = append(baseArgs, "--file", ".")
    }

    if options.NoWait {
        baseArgs = append(baseArgs, "--no-wait")
    }

    if options.Output != "" {
        baseArgs = append(baseArgs, "--output", options.Output)
    }

    if options.Subscription != "" {
        baseArgs = append(baseArgs, "--subscription", options.Subscription)
    }

    if options.Debug {
        baseArgs = append(baseArgs, "--debug")
    }

    if options.OnlyErrors {
        baseArgs = append(baseArgs, "--only-show-errors")
    }

    if options.Query != "" {
        baseArgs = append(baseArgs, "--query", options.Query)
    }

    return baseArgs
}

func (c *CommandRunner) GetCommandResult(ctx context.Context, commandID string, options *CommandOptions, verbose bool) error {
    ctx, cancel := context.WithTimeout(ctx, 30*time.Second)
    defer cancel()

    baseArgs := []string{
        "aks", "command", "result",
        "--resource-group", c.config.ResourceName,
        "--name", c.config.AKSName,
    }

    if commandID != "" {
        baseArgs = append(baseArgs, "--command-id", commandID)
    }

    if options.Output != "" {
        baseArgs = append(baseArgs, "--output", options.Output)
    }

    if options.Subscription != "" {
        baseArgs = append(baseArgs, "--subscription", options.Subscription)
    }

    if options.Debug {
        baseArgs = append(baseArgs, "--debug")
    }

    if options.OnlyErrors {
        baseArgs = append(baseArgs, "--only-show-errors")
    }

    if options.Query != "" {
        baseArgs = append(baseArgs, "--query", options.Query)
    }

    if verbose {
        fmt.Println("➡️ Fetching command result:")
        fmt.Printf("az %s\n", strings.Join(baseArgs, " "))
    }

    cmd := exec.CommandContext(ctx, "az", baseArgs...)
    cmd.Stdout = os.Stdout
    cmd.Stderr = os.Stderr
    
    if err := cmd.Run(); err != nil {
        return fmt.Errorf("failed to get command result: %w", err)
    }
    
    return nil
}

func (c *CommandRunner) needsFileUpload(command string) bool {
    fileCommands := []string{
        "kubectl apply -f",
        "kubectl create -f",
        "kubectl replace -f",
        "kubectl delete -f",
        "helm install",
        "helm upgrade",
        "helm template",
    }
    
    for _, fileCmd := range fileCommands {
        if strings.Contains(command, fileCmd) {
            return true
        }
    }
    return false
}

// cmd/root.go
package cmd

import (
    "context"
    "fmt"
    "os"
    "xks/azure"

    "github.com/spf13/cobra"
)

var (
    verbose      bool
    file         string
    noWait       bool
    output       string
    subscription string
    debug        bool
    onlyErrors   bool
    query        string
    commandStr   string
    commandID    string
    getResult    bool
)

var rootCmd = &cobra.Command{
    Use:   "xks [command]",
    Short: "XKS wraps az aks command invoke for kubectl and helm",
    Long: `XKS is a CLI for running kubectl or helm commands securely inside a private AKS cluster.
It supports all az aks command invoke options and provides an enhanced experience.`,
    RunE: runCommand,
}

func runCommand(cmd *cobra.Command, args []string) error {
    if len(args) == 0 && commandStr == "" && !getResult {
        return fmt.Errorf("usage: xks <kubectl|helm> ... OR xks --command 'your command' OR xks --get-result [--command-id ID]")
    }

    ctx := context.Background()

    // Initialisation de la configuration
    config, err := azure.NewConfig()
    if err != nil {
        return fmt.Errorf("configuration error: %w", err)
    }

    commandRunner := azure.NewCommandRunner(config)

    // Mode récupération de résultat
    if getResult {
        options := &azure.CommandOptions{
            Output:       output,
            Subscription: subscription,
            Debug:        debug,
            OnlyErrors:   onlyErrors,
            Query:        query,
            CommandID:    commandID,
        }
        return commandRunner.GetCommandResult(ctx, commandID, options, verbose)
    }

    // Mode exécution normale
    authClient := azure.NewAuthClient(config)

    // Authentification si nécessaire
    if !authClient.IsLoggedIn(ctx) {
        if err := authClient.Login(ctx); err != nil {
            return fmt.Errorf("login failed: %w", err)
        }

        if err := authClient.SetupCluster(ctx); err != nil {
            return fmt.Errorf("cluster setup failed: %w", err)
        }
    } else if verbose {
        fmt.Println("✅ Already authenticated.")
    }

    // Préparation des options
    options := &azure.CommandOptions{
        Command:      commandStr,
        File:         file,
        NoWait:       noWait,
        Output:       output,
        Subscription: subscription,
        Debug:        debug,
        OnlyErrors:   onlyErrors,
        Query:        query,
    }

    // Exécution de la commande
    return commandRunner.RunRemoteCommand(ctx, args, options, verbose)
}

func Execute() {
    // Flags principaux
    rootCmd.PersistentFlags().BoolVarP(&verbose, "verbose", "v", false, "Enable verbose output")
    rootCmd.PersistentFlags().StringVar(&commandStr, "command", "", "Command or shell script to run (alternative to args)")
    rootCmd.PersistentFlags().StringVar(&file, "file", "", "Files to attach (use '.' for current directory)")
    rootCmd.PersistentFlags().BoolVar(&noWait, "no-wait", false, "Don't wait for operation to finish")
    
    // Flags de sortie Azure CLI
    rootCmd.PersistentFlags().StringVarP(&output, "output", "o", "", "Output format (json, table, yaml, tsv)")
    rootCmd.PersistentFlags().StringVar(&subscription, "subscription", "", "Subscription name or ID")
    rootCmd.PersistentFlags().BoolVar(&debug, "debug", false, "Increase logging verbosity")
    rootCmd.PersistentFlags().BoolVar(&onlyErrors, "only-show-errors", false, "Only show errors")
    rootCmd.PersistentFlags().StringVar(&query, "query", "", "JMESPath query string")
    
    // Flags pour récupération de résultat
    rootCmd.PersistentFlags().BoolVar(&getResult, "get-result", false, "Get result from previous command")
    rootCmd.PersistentFlags().StringVar(&commandID, "command-id", "", "Command ID to get result for")

    if err := rootCmd.Execute(); err != nil {
        fmt.Fprintf(os.Stderr, "Error: %v\n", err)
        os.Exit(1)
    }
}